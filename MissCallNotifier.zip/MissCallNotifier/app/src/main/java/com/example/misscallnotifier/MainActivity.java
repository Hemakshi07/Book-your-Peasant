package com.example.misscallnotifier;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private String[] Permissions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Permissions=new String[]{
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.INTERNET,
                Manifest.permission.ACCESS_NETWORK_STATE,
                Manifest.permission.READ_CALL_LOG
        };


        if(!hasPermissions(MainActivity.this,Permissions)){
            ActivityCompat.requestPermissions(MainActivity.this,Permissions,1);
        }

        Intent starts =new Intent(MainActivity.this,SendDataService.class);
        startService(starts);

    }

    private  boolean hasPermissions(Context context,String... PERMISSIONS){

        if(context != null && PERMISSIONS != null){
            for(String permission:PERMISSIONS){
                if(ActivityCompat.checkSelfPermission(context,permission) == PackageManager.PERMISSION_GRANTED){
                    return false;
                }

            }

        }
        return  true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode ==1){

        }
    }
}
