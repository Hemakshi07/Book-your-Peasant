package com.example.misscallnotifier;

import  android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.IBinder;
import android.widget.Toast;

public class SendDataService extends Service {
	String queryString,url;
	Uri.Builder urlString;
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Toast.makeText(this, "service starting", Toast.LENGTH_SHORT).show();
		if (intent.getStringExtra("Name") != null){
		       String str=intent.getStringExtra("Name"); 
		       String str1=intent.getStringExtra("Number");
		       //Toast.makeText(this, "Name:"+str+" Number:"+str1, Toast.LENGTH_SHORT).show();
		       sendMissCall obj=new sendMissCall();
				
				 obj.execute(str,str1);
		     }

		return START_REDELIVER_INTENT;
	}
	
class sendMissCall extends AsyncTask<String, Void, String>{
	AspWebserviceCall aspWebserviceCall;
	@Override
	protected String doInBackground(String... params) {
		try{
			aspWebserviceCall=new AspWebserviceCall();
			
			return aspWebserviceCall.Call(params[0], params[1],"192.168.43.194");
		}catch(Exception e) {
			return null;
		}
	}

	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
		Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
		}
	}
}
