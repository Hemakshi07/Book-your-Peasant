package com.Lapps.miscallnotify;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.TelephonyManager;
import android.widget.Toast;

public class MissedCall extends BroadcastReceiver{
	static boolean isRinging=false;
    static boolean isReceived=false;
    static String callerPhoneNumber;
	@Override
	public void onReceive(Context context, Intent intent) {
		 String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
		 
	        if(state==null)
	            return;
	        
	        //phone is ringing
	        if(state.equals(TelephonyManager.EXTRA_STATE_RINGING)){           
	            isRinging =true;
	            //get caller's number
	            Bundle bundle = intent.getExtras();
	            callerPhoneNumber= bundle.getString("incoming_number");
	        }
	        
	        //phone is received
	        if(state.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)){
	            isReceived=true;
	        }
	 
	      
	        if (state.equals(TelephonyManager.EXTRA_STATE_IDLE))
	        {
	                  // If phone was ringing(ring=true) and not received(callReceived=false) , then it is a missed call
	                   if(isRinging==true&&isReceived==false)
	                   {
	                	   String name=ContactName(context, callerPhoneNumber);
	                            Toast.makeText(context, "missed call : "+name, Toast.LENGTH_LONG).show();
	                            isRinging=false;
	                            Intent i=new Intent(context,SendDataService.class);
	                            i.putExtra("Name",name);
	                            i.putExtra("Number", callerPhoneNumber);
	                            context.startService(i);
	                            
	                   }
	                   isReceived=false;
	      }
	 
	}
	private String ContactName(Context context, String number) {
		String name = null;
		String contactId = null;
		
		
		String[] projection = new String[] {
		        ContactsContract.PhoneLookup.DISPLAY_NAME,
		        ContactsContract.PhoneLookup._ID};
		Uri contactUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number));
		Cursor cursor = context.getContentResolver().query(contactUri, projection, null, null, null);
		if (cursor.moveToFirst()) {
			contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup._ID));
		    name =      cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));
		}else{
			name="Contact Not Found In PhoneBook";
		}
		
		return name;
	}
}
